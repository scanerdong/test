#include "Common.h"
#include <iostream>
#include <pthread.h>
#include <list>
#include <vector>
#include <iterator>
#include "Singleton.h"
#include "Socket.h"
#include "MutexMgr.h"
#include "MemMgr.h"
#include "FdResMgr.h"
#include "test.h"
#include <linux/types.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <linux/if_ether.h>
#include <linux/if_packet.h>
#include <sys/types.h>
#include <sys/syscall.h>

using namespace std;

static int32 s_i32Count = 5;
//static pthread_attr_t s_attr;//�߳����ԣ��ڴ����߳����õ���
static pthread_mutex_t s_mutexId;//�������ṹ��
//static pthread_mutexattr_t s_muteattr; //�����������Խṹ��
static pthread_cond_t s_condId;  //���������ṹ��
//static pthread_condattr_t s_condAttr;//�������Խṹ��
pthread_t* pTid1;
pthread_t* pTid2;

unsigned char chRecvValue;//�����̶߳�ȡ����һ���ֽ�
CTcpClientSocket* pclTcpClientSocket = NULL;//�׽ӿ�
static const char s_achIACsToSend[] = {
    //IAC, DO, TELOPT_ECHO,
    //IAC, DO, TELOPT_NAWS,
    //IAC, DO, TELOPT_LFLOW,
    IAC, WILL, TELOPT_ECHO,    //����
    IAC, WILL, TELOPT_SGA      //ȫ˫��
};

pid_t gettid()
{
    return syscall(SYS_gettid);
}

char GetChar()
{
	uint8 au8RecvBuf[1024];
	int32 i32RecvLen = 0;
    fd_set fdsReadable;
    struct timeval stTimeout = {1,0};
    int32 i32FdsReadableCount = 0;
    char achBuf[100] = {0};

    while(1)
    {
        FD_SET(pclTcpClientSocket->GetFd(), &fdsReadable);

        select(pclTcpClientSocket->GetFd() + 1, &fdsReadable, NULL, NULL, &stTimeout);

        i32FdsReadableCount = FD_ISSET(pclTcpClientSocket->GetFd(), &fdsReadable);

        if(i32FdsReadableCount > 0)
        {
        
            i32RecvLen = pclTcpClientSocket->Recv(au8RecvBuf, 1);  
            
            if((i32RecvLen <= 0) && (errno != EINTR || errno != EWOULDBLOCK || errno != EAGAIN))//���ӶϿ�
            {
                sprintf(achBuf, "pclTcpClientSocket->Recv--errno is %d", errno);
                perror(achBuf);        
                return -1;
            }
            
            switch(i32RecvLen)
            {
                case -1:
                    printf("receive error no is %d", errno);
                    perror("receive");
                    pclTcpClientSocket->CloseFd();
                    break;

                case 0:
                    printf("receive len is %d \n", i32RecvLen);
                    break;

                default:
                    OM_INFO("receive msg: %s\n", au8RecvBuf);
                    return au8RecvBuf[0];
                    break;
            }
        }
    }

}
#if 0

char GetChar()
{
    uint8 au8Char[1];
    int32 i32RecvLen;
    
    i32RecvLen = pclTcpClientSocket->Recv(au8Char, 1);
    if(i32RecvLen <= 0) return FAIL;

    return au8Char[0];
}
#endif

int32 PutChar(char c)
{
    int32 i32SendLen;
    
    if(pclTcpClientSocket != NULL)
    {
        i32SendLen = pclTcpClientSocket->Send(&c, 1);  
    }

    return i32SendLen;
}

_enResult PutString(const char* pchMsg)
{
    if(pchMsg == NULL) return FAIL;

    if(pclTcpClientSocket->Send((char*)pchMsg, strlen(pchMsg)+1) <= 0) 
        return FAIL;

    return SUCC;
}

void HandleIAC()
{
    uint8 u8C1;
    uint8 u8C2;
    u8C1 = GetChar();

    if(u8C1 == SB)
    {
        //1. ���c1 == SB: response SE
        PutChar(IAC);
        PutChar(SE);

    }
    else if(u8C1 == DO || u8C1 == DONT || u8C1 == WILL || u8C1 == WONT)
    {
        //2. will, wont, do, dontָ��
        u8C2 = GetChar();
        OM_INFO("c1 %d, c2 %d\n", u8C1, u8C2);
    }
    else
    {
       //3. ����������
    }
}

CTcpClientSocket* WaitLink()
{
    CTcpServerSocket* pclTcpServerSocket;
    CTcpClientSocket* pclTcpClientSocket;
    string strForeignAddr;
    pclTcpServerSocket = new CTcpServerSocket(6000);
    
    pclTcpClientSocket = pclTcpServerSocket->Accept(strForeignAddr);

    OM_DEBUG("recv connect strForeignAddr:%s\n", strForeignAddr.c_str());
    
    return pclTcpClientSocket;
}

void* RecvTask(void* pArg)
{
    uint8 u8Count = *(uint8*)pArg;
    uint8 u8Loop;
    int32 i32Ret;

    printf("RecvTask tid:%u\n", (uint32)gettid());

    //pthread_detach(pthread_self());
    pclTcpClientSocket = WaitLink();
    
    //���ͷ�����ѡ��
    pclTcpClientSocket->Send(s_achIACsToSend, sizeof(s_achIACsToSend));
    PutString("telnet server\r\n");
    
    for(u8Loop = 0; u8Loop < u8Count; u8Loop++)
    {
        usleep(20*1000);

        pthread_mutex_lock(&s_mutexId);//�����������ᶪʧ����

        chRecvValue = GetChar();
        if(chRecvValue == IAC)
        {
            HandleIAC();
        }
        else
        {
            pthread_cond_signal(&s_condId);
            
            OM_DEBUG("Send signal\n");
        }
        
        pthread_mutex_unlock(&s_mutexId);
        i32Ret = pthread_kill(*pTid2, 0);
        if(i32Ret != 0)
        {
            OM_DEBUG("SendTask has exit\n");
            return NULL;
        }
        
    }

    OM_DEBUG("RecvTask exit\n");

    return (void*)"RecvTask exit";
}

void* SendTask(void* pArg)
{
    uint8 u8Count = *(uint8*)pArg;
    uint8 u8Loop;
    int32 i32Ret;

    //pthread_detach(pthread_self());
    
    printf("SendTask tid:%u\n", (uint32)gettid());
    //while(1) ; //�����߳�CPUʹ����

    for(u8Loop = 0; u8Loop < u8Count; u8Loop++)
    {
        pthread_mutex_lock(&s_mutexId);
        pthread_cond_wait(&s_condId, &s_mutexId);
        OM_DEBUG("Receive signal\n");
        PutChar(chRecvValue);
        //sleep(5);
        pthread_mutex_unlock(&s_mutexId);

        i32Ret = pthread_kill(*pTid1, 0);
        if(i32Ret != 0)
        {
            OM_DEBUG("RecvTask has exit\n");
            return NULL;
        }
    }

    OM_DEBUG("SendTask exit\n");

    return (void*)"SendTask exit";
}

void SysInit()
{
    TSingleton<CMutexMgr>::Instance()->Init();
    TSingleton<CMemMgr>::Instance()->Init();
    TSingleton<CFdResMgr>::Instance()->Init();
}

int32 main()
{
    pthread_t threadId1,threadId2;
    int32 i32Ret;
    uint8 u8LoopCount = 20;
    
    pTid2 = &threadId2;
    pTid1 = &threadId1;
    
    SysInit();
    
    //��ʼ����
    pthread_mutex_init(&s_mutexId, NULL);//���ṹ�������Խṹ������Ϊ��ʱ���������̬�ṹ��ֵPTHREAD_MUTEX_INITIALIZERһ����Ч��
    pthread_cond_init(&s_condId, NULL);//�����ṹ���������Խṹ������Ϊ��ʱ�뾲̬�ṹPTHREAD_COND_INITIALIZERһ����Ч��
    
    //�������߳�
    i32Ret = pthread_create(&threadId1, NULL, RecvTask, (void*)&u8LoopCount);
    if(i32Ret != 0)
    {
        OM_ERROR("Create ThreadTask1 error\n");
    }

    i32Ret = pthread_create(&threadId2, NULL, SendTask, (void*)&u8LoopCount);
    if(i32Ret != 0)
    {
        OM_ERROR("Create ThreadTask2 error\n");
    }

    //��ӡ�̺߳�
    printf("main thread id:0x%08x, RecvTask thread id:0x%08x, SendTask thread id:0x%08x\n",
    (uint32)pthread_self(), (uint32)threadId1, (uint32)threadId2);
    
    printf("process id:%u, main tid:%u\n", (uint32)getpid(), (uint32)gettid());
    
    //һ���̲߳��ܱ�����̵߳ȴ���Ҳ����˵��һ���߳�ֻ��ֻ�ܵ���һ��pthread_join������ֻ��һ������ȷ���أ������Ľ�����ESRCH ����
    char* pchRet;
    pthread_join(threadId2, (void**)&pchRet);
    printf("*pi32ThreadRet:%s\n", pchRet);//pchRet���Խ����̷߳���ֵ�������߳��з���ֵ��NULL�����Եõ�NULL
    pthread_join(threadId1, (void**)&pchRet);
    printf("*pi32ThreadRet:%s\n", pchRet);

    //���ٴ����Ļ�����������
    pthread_mutex_destroy(&s_mutexId);
    pthread_cond_destroy(&s_condId);
    return 0;
}

