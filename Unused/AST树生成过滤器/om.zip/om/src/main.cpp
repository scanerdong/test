#include "UnlockQueue.h"
#include <iostream>
#include <algorithm>
#include <pthread.h>
#include <time.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <string>
#include "DFilter.h"

using namespace std;

#pragma pack(1)
struct student_info
{
   unsigned int len; //���ȣ�����len������4���ֽ�
   long stu_id;
   unsigned int age;
   unsigned int score;
   char achInfo[0]; //ѧ����˵��
};
#pragma pack()
void print_student_info(const student_info *stu_info)
{
    if(NULL == stu_info)
        return;
    
    printf("len:%u\t",stu_info->len);
    printf("id:%ld\t",stu_info->stu_id);
    printf("age:%u\t",stu_info->age);
    printf("score:%u\t",stu_info->score);
    printf("info:%s\n",stu_info->achInfo);
}


int one_pck_call(unsigned char* pkg, unsigned int len, void* param)
{
    int result = 0;
    
    print_student_info((student_info*)pkg);
    
    return result;
}


student_info * get_student_info()
{
    static long id;
    static unsigned int age;
    static unsigned int score;
    static unsigned int infolen = 1;
    
     student_info *stu_info = (student_info *)malloc(sizeof(student_info) + infolen);
     if (!stu_info)
     {
        fprintf(stderr, "Failed to malloc memory.\n");
        return NULL;
     }

     for(unsigned int i=0; i<infolen; i++)
     {
        stu_info->achInfo[i] = 'A';
     }
     stu_info->achInfo[infolen-1] = 0;
     
     stu_info->stu_id = id;
     stu_info->age = age;
     stu_info->score = score;
     stu_info->len = sizeof(student_info) + infolen;

     id++;age++;score++;infolen = infolen % 200 + 1;
     //print_student_info(stu_info);
     return stu_info;
}
 
void * consumer_proc(void *arg)
{
     UnlockQueue* queue = (UnlockQueue *)arg;
     static unsigned char ach_stu_info[1000];
     
     while(1)
     {
         usleep(10);
         #if 1
         unsigned int len = queue->HandleOnePacket();
         if(len == 0)
         {
             //printf("------------------------------------------\n");
             //printf("UnlockQueue length after get: %u\n", queue->GetDataLen());
             //printf("------------------------------------------\n");
         }
         #endif
     }
     return (void *)queue;
}
 
void * producer_proc(void *arg)
{
  time_t cur_time;
  UnlockQueue *queue = (UnlockQueue*)arg;
  while(1)
  {
      //printf("******************************************\n");
      student_info *stu_info = get_student_info();
      //printf("put a student info to queue.\n");
      queue->Put( (unsigned char *)stu_info, stu_info->len);
      free(stu_info);
      //printf("UnlockQueue length after put: %u\n", queue->GetDataLen());
      //printf("******************************************\n");
      usleep(100);
  }
 return (void *)queue;
}





 
 struct RefStr
 {
     RefStr() : _pstart(NULL), _len(0) {}
     RefStr(const char* const str, const size_t len) : _pstart(str), _len(len) {}
 
     int assign(const char* const str, const size_t len)
     {
         _pstart = str;
         return (_len = len);
     }
 
     void resize(size_t len) { _len = len;    }
     const char* buf() const { return _pstart;}
     void clear()            { _len = 0;      }
     size_t size() const     { return _len;   }
     bool empty() const      { return _len == 0; }
 
 protected:
     const char* _pstart;
     size_t _len; //��Ҫ����'\0'
 };




void get(RefStr& str)
{
    static char insert_address[] = "<insert address>";
    str.assign((char *)insert_address, sizeof(insert_address) - sizeof(insert_address[0]));
}

#if 0
#include <arpa/inet.h>
int main(int argc, char** argv)
{
    char ach[100];
    RefStr str;
    
    get(str);
    memcpy(ach,str.buf(),str.size());
    printf(ach);

    
    exit(0);
    
    UnlockQueue unlockQueue(30000);
    if(!unlockQueue.Initialize(one_pck_call, NULL))
    {
        return -1;
    }
 
    pthread_t consumer_tid, producer_tid;
 
    printf("multi thread test.......\n");
 
    if(0 != pthread_create(&producer_tid, NULL, producer_proc, (void*)&unlockQueue))
    {
         fprintf(stderr, "Failed to create consumer thread.errno:%u, reason:%s\n",
                 errno, strerror(errno));
         return -1;
    }
 
    if(0 != pthread_create(&consumer_tid, NULL, consumer_proc, (void*)&unlockQueue))
    {
           fprintf(stderr, "Failed to create consumer thread.errno:%u, reason:%s\n",
                   errno, strerror(errno));
           return -1;
    }
 
    pthread_join(producer_tid, NULL);
    pthread_join(consumer_tid, NULL);
 
    return 0;
 }
#endif
char CharToInt(char ch){
        if(ch>='0' && ch<='9')return (char)(ch-'0');
        if(ch>='a' && ch<='f')return (char)(ch-'a'+10);
        if(ch>='A' && ch<='F')return (char)(ch-'A'+10);
        return -1;
}

char StrToBin(char *str){
        char tempWord[2];
        char chn;

        tempWord[0] = CharToInt(str[0]);
        tempWord[1] = CharToInt(str[1]);

        chn = (tempWord[0] << 4) | tempWord[1];

        return chn;
}

void urlToUtf8(const string& str, string& output)
{
   //string output="";
        char tmp[2];
        int i=0,idx=0,ndx,len=str.length();
        
        while(i<len){
                if(str[i]=='%'){
                        tmp[0]=str[i+1];
                        tmp[1]=str[i+2];
                        output += StrToBin(tmp);
                        i=i+3;
                }
                else if(str[i]=='+'){
                        output+=' ';
                        i++;
                }
                else{
                        output+=str[i];
                        i++;
                }
        }
        
        return ;
}


bool substrFromStr(const string& src, string& out, const string& start_flag, const string& end_flag, const unsigned int max_keyword_len)
{
    size_t startpos,endpos;
    
    if((startpos=src.find(start_flag)) != string::npos)
    {    
        startpos += start_flag.length();
        
        endpos = src.find(end_flag, startpos);    
        if(endpos == string::npos)//û�ҵ�&�ţ���ĳ�һ������
        {
            endpos = (src.length() > startpos+max_keyword_len)
                     ? startpos+max_keyword_len : src.length();                
        }else
        {
            endpos = (endpos > startpos+max_keyword_len)
                     ? startpos+max_keyword_len : endpos;                
        }
        
        out = src.substr(startpos, endpos-startpos);
        
        return true;
    }else
    {
        return false;
    }
    
}

struct Test
{
    static int haha;
    int ha;
};

class filter_base
{
public:
	filter_base(){cout << "base()" << endl;}
	virtual ~filter_base(){cout << "~base()" << endl;}
	virtual bool is_filter(const char* raw_buf,int buf_len) = 0;
	virtual void set_filtercfg_path(const std::string& cfg_path) = 0;
};

class Filter : public filter_base
{
public:
	Filter(){cout<<"XdrFilter()" << endl;}
	~Filter(){cout<<"~XdrFilter()" << endl;}
	
	bool is_filter(const char* raw_buf,int buf_len)
	{
        return true;
    }
	void set_filtercfg_path(const std::string& cfg_path)
	{
        {cout<<"set_filtercfg_path()" << endl;}
    }
};

class base_net_send{
public:
	base_net_send()
	{
        _filter_mod = new Filter();
    }
    
	virtual ~base_net_send()
	{
        delete _filter_mod;
    }

	void set_filtercfg_path(const std::string & cfg_path){
		_filter_mod->set_filtercfg_path(cfg_path);
	}

public:
	filter_base*	_filter_mod;

};


class zmq_net_send:public base_net_send{
	
public:
	zmq_net_send()
		:base_net_send()
	{
	}
    
	virtual ~zmq_net_send(){}

    string m_str;
};

class Task
{
public:
	Task()
        {string str = "dada";
          base = new zmq_net_send();
          base->set_filtercfg_path(str);
        }
    base_net_send* base;
};

int main(int argc, char** argv)
{
    
    Task* task;
    task = new Task();
    

    //delete base;
    
#if 0
DFilter df;
united_dpi::relay_msg_base msg;
msg.commInfo.u32InDstIp = 0x01020304;
msg.commInfo.u32InSrcIp = 0x15060708;
msg.commInfo.u16InDstPort = 0x0a0b;
msg.commInfo.u16InSrcPort = 0x0c0d;
msg.commInfo.u8L4Protocal = 0x6;

if(argc < 2) return -1;

int ret = df.scan(argv[1]);
if(ret < 0)
    cout << "scan"<<ret << endl;

ret = df.make_ast();
if(ret < 0)
    cout << "make_ast"<<ret << endl;

ret = df.semantic_check(df.root);
if(ret < 0)
    cout << "check"<<ret << endl;

bool r = df.exec_msg(df.root,msg);
cout << "exec " << r << endl;
#endif


return 0;
}

